package main;

public class CommonConfig {
  public String numberOfPreferredNeighbors;
  public String unchokingInterval;
  public String optimisticUnchokingInterval;
  public String fileName;
  public String fileSize;
  public String pieceSize;
}
